import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-with-social',
  templateUrl: './with-social.component.html'
})
export class WithSocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
